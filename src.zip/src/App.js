import{useState, useEffect }from 'react';
import './App.css';
function App(){

    const [imieNazwisko, setImieNazwisko] = useState('');
    const [email, setEmail] = useState('');
    const [wiadomosc, setWiadomosc] = useState('');

    const [wpisy, setWpisy] = useState(()=>{
        const zapisaneWpisy = localStorage.getItem('wpisy_baza');
        if(zapisaneWpisy !== null){
            return JSON.parse(zapisaneWpisy);
        }else{
            return [];
        }
    });

    //######################################################################
    useEffect(()=>{
        localStorage.setItem('wpisy_baza', JSON.stringify(wpisy));
    }, [wpisy]);

    //######################################################################
    const dodajWpis =(e)=>{
        e.preventDefault();

        if(imieNazwisko === ''){
            alert('Wype�nij imi� i nazwisko!');
            return;
        }

        if(email === ''){
            alert('Wype�nij adres e-mail!');
            return;
        }

        if(wiadomosc === ''){
            alert('Wype�nij tre�� wiadomo�ci!');
            return;
        }

        const nowyWpis ={
            id: Date.now(),
            imieNazwisko: imieNazwisko,
            email: email,
            wiadomosc: wiadomosc,
        };

        const nowaTablicaWpisow = [nowyWpis, ...wpisy];
        setWpisy(nowaTablicaWpisow);

        setImieNazwisko('');
        setEmail('');
        setWiadomosc('');
    };

    //######################################################################
    let zawartoscListy;
    if(wpisy.length === 0){

        zawartoscListy =(
            <p style={{fontStyle: 'italic', color: 'gray' }}>Brak zapisanych wpis�w.</p>
        );
    }else{

        zawartoscListy =(
            <div style={{display: 'flex', flexDirection: 'column', gap: '15px' }}>
               {wpisy.map(function(wpis){
                    return(
                        <div key={wpis.id}style={{border: '1px solid #ccc', padding: '15px', borderRadius: '5px', backgroundColor: '#f9f9f9' }}>
                            <p style={{margin: '0 0 5px 0' }}><strong>Imi� i nazwisko:</strong>{wpis.imieNazwisko}</p>
                            <p style={{margin: '0 0 5px 0' }}><strong>E-mail:</strong>{wpis.email}</p>
                            <p style={{margin: '0' }}><strong>Wiadomo��:</strong>{wpis.wiadomosc}</p>
                        </div>
                    );
                })}
            </div>
        );
    }
    return(
        <div style={{maxWidth: '600px', margin: '30px auto', fontFamily: 'Arial, sans-serif', padding: '20px' }}>
            <h2>Dodaj nowy wpis</h2>
            <form onSubmit={dodajWpis}style={{display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '30px' }}>
                <input
                    type="text"
                    placeholder="Imi� i nazwisko"
                    value={imieNazwisko}
                    onChange={function(e){setImieNazwisko(e.target.value); }}
                    style={{padding: '10px', fontSize: '16px' }}
                />
                <input
                    type="email"
                    placeholder="Adres e-mail"
                    value={email}
                    onChange={function(e){setEmail(e.target.value); }}
                    style={{padding: '10px', fontSize: '16px' }}
                />
                <textarea
                    placeholder="Tre�� wiadomo�ci"
                    value={wiadomosc}
                    onChange={function(e){setWiadomosc(e.target.value); }}
                    rows="4"
                    style={{padding: '10px', fontSize: '16px' }}
                />
                <button type="submit" style={{padding: '10px', fontSize: '16px', backgroundColor: '#007BFF', color: 'white', border: 'none', cursor: 'pointer' }}>
                    Dodaj wpis
                </button>
            </form>
            <hr />
            <h2>Lista wpis�w</h2>
           {zawartoscListy}
        </div>
    );
}

//######################################################################
export default App;